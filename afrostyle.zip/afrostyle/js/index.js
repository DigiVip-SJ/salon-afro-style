const menu = document.querySelector(".menu");
const navOpen = document.querySelector(".hamburger");
const navClose = document.querySelector(".close");
const navBar = document.querySelector(".nav");

const navLeft = menu.getBoundingClientRect().left
navOpen.addEventListener("click",()=>{
    if(navLeft < 0){
        menu.classList.add("show");
        document.body.classList.add("show");
        navBar.classList.add("show");
    }
});

navClose.addEventListener("click",()=>{
    if(navLeft < 0){
        menu.classList.remove("show");
        document.body.classList.remove("show");
        navClose.classList.remove("show");
    }
});

// Fix Nav
const navHeight = navBar.getBoundingClientRect().height;
window.addEventListener("scroll", ()=> {
    const scrollHeight = window.pageYOffset;
    if(scrollHeight > navHeight){
        navBar.classList.add("fix-nav");
    }else{
        navBar.classList.remove("fix-nav");
    }
});

// Scroll To
const links = [...document.querySelectorAll(".scroll-link")];

links.map(link=>{
    link.addEventListener("click", e=>{
        e.preventDefault();

        const id = e.target.getAttribute("href").slice(1);
        const el = document.getElementById(id);
        let position = el.offsetTop - navHeight;

        window.scrollTo({
            top: position,
            left:0,
        });

        navBar.classList.remove("show")
        menu.classList.remove("show")
        document.body.classList.remove("show")
    });
});

new TypeIt("#type1",{
    speed: 120,
    loop: true,
    waitUntilVisible: true,
})
.type("Afro", {delay: 400})
.pause(500)
.delete(9)
.type("Style", {delay:400})
.pause(500)
.delete(9)
.go();

new TypeIt("#type2",{
    speed: 120,
    loop: true,
    waitUntilVisible: true,
})
.type("Afro", {delay: 400})
.pause(500)
.delete(9)
.type("Style", {delay:400})
.pause(500)
.delete(9)
.go();
//   GSAP

gsap.from(".logo", {opacity: 0, duration: 1, delay: 0.5, y: -10});
gsap.from(".hamburger", {opacity: 0, duration: 1, delay: 1, x: 20});
gsap.from(".banner", {opacity: 0, duration: 1, delay: 1.5, x: -200});
gsap.from(".hero h3", {opacity: 0, duration: 1, delay: 2, y: -50});
gsap.from(".hero h1", {opacity: 0, duration: 1, delay: 2.5, y: -45});
gsap.from(".hero h4", {opacity: 0, duration: 1, delay: 3, y: -30});
gsap.from(".hero a", {opacity: 0, duration: 1, delay: 3.5, y: 50});
gsap.from(".nav-item", {
    opacity: 0, 
    duration: 1, 
    delay: 1.2, 
    y: 30, 
    stagger: 0.2, 
});

gsap.from(".icons span", {
    opacity: 0, 
    duration: 1, 
    delay: 4, 
    x: -30, 
    stagger: 0.2, 
});

// calendar

const date = new Date();

const renderCalendar = () => {
  date.setDate(1);

  const monthDays = document.querySelector(".days");

  const lastDay = new Date(
    date.getFullYear(),
    date.getMonth() + 1,
    0
  ).getDate();

  const prevLastDay = new Date(
    date.getFullYear(),
    date.getMonth(),
    0
  ).getDate();

  const firstDayIndex = date.getDay();

  const lastDayIndex = new Date(
    date.getFullYear(),
    date.getMonth() + 1,
    0
  ).getDay();

  const nextDays = 7 - lastDayIndex - 1;

  const months = [
    "Janvier",
    "Février",
    "Mars",
    "Avril",
    "Mai",
    "Juin",
    "Juillet",
    "Août",
    "Septembre",
    "Octobre",
    "Novembre",
    "Décembre",
  ];

  document.querySelector(".date h1").innerHTML = months[date.getMonth()];

  document.querySelector(".date p").innerHTML = new Date().toDateString();

  let days = "";

  for (let x = firstDayIndex; x > 0; x--) {
    days += `<div class="prev-date">${prevLastDay - x + 1}</div>`;
  }

  for (let i = 1; i <= lastDay; i++) {
    if (
      i === new Date().getDate() &&
      date.getMonth() === new Date().getMonth()
    ) {
      days += `<div class="today">${i}</div>`;
    } else {
      days += `<div>${i}</div>`;
    }
  }

  for (let j = 1; j <= nextDays; j++) {
    days += `<div class="next-date">${j}</div>`;
    monthDays.innerHTML = days;
  }
};

document.querySelector(".prev").addEventListener("click", () => {
  date.setMonth(date.getMonth() - 1);
  renderCalendar();
});

document.querySelector(".next").addEventListener("click", () => {
  date.setMonth(date.getMonth() + 1);
  renderCalendar();
});

renderCalendar();


// Glidejs

const glide = document.querySelector(".glide");

if(glide)
new Glide(glide, {
type: "carousel",
startAt : 0,
perView: 3,
gap: 30,
hoverpause: true,
autoplay: 2000,
animationDuration: 800,
animationTimingFung: "ease-in-out",
breakpoints: {
    996 : {
        perView: 2,
    },

    768 : {
        perView: 1,
    },
},
}).mount();

AOS.init();